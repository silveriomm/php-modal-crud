<?php 

include "connect.php";

if(isset($_POST['displaySend']))
{
    $table='<table class="table table-sm my-3">
          <thead class="thead-dark">
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Course</th>
              <th scope="col">Phone</th>
              <th scope="col" colspan="2">Actions</th>
            </tr>
          </thead>
          <tbody>';
            $sql = "SELECT * FROM student";
            $result = mysqli_query($conn, $sql);
            while($row=mysqli_fetch_assoc($result))
            {
                $id = $row['id'];
                $name = $row['name'];
                $course = $row['course'];
                $phone = $row['phone'];
                $table .='<tr>
                  <th scope="row">'.$id.'</th>
                  <td>'.$name.'</td>
                  <td>'.$course.'</td>
                  <td>'.$phone.'</td>
                  <td>
                    <button onclick="updateuser('.$id.')" class="btn btn-dark btn-sm">update</button>
                    <button onclick="deleteuser('.$id.')" class="btn btn-danger btn-sm">delete</button>
                  </td>
                </tr>';
            }
          $table .='</tbody>
        </table>';

        echo $table;
}

?>
