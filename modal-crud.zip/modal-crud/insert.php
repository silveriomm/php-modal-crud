<?php 

include "connect.php";

extract($_POST);

if(isset($_POST['nameSend']) &&
    isset($_POST['courseSend']) &&
        isset($_POST['phoneSend']))
{
    $sql = "INSERT INTO student (name, course, phone) VALUES ('$nameSend', '$courseSend', '$phoneSend')";
    
    $result = mysqli_query($conn, $sql);
}
?>
