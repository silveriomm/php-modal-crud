<?php 

include "connect.php";

if(isset($_POST['deleteSend']))
{
    $id = $_POST['deleteSend'];

    $sql = "DELETE FROM student WHERE id=$id";
    $result = mysqli_query($conn, $sql);
}

?>
