<?php 

include "connect.php";

if(isset($_POST['updateid']))
{
    $id = $_POST['updateid'];
    
    $sql = "SELECT * FROM student WHERE id=$id";

    $result = mysqli_query($conn, $sql);
    $response = array();

    while($row = mysqli_fetch_assoc($result))
    {
        $response=$row;
    }

    echo json_encode($response);
}
else 
{
    $response['status'] = 200;
    $response['message'] = "Invalid or data not found.";
}

// upadate query
if(isset($_POST['hiddendata']))
{
    $user_id = $_POST['hiddendata'];
    $name = $_POST['uname'];
    $course = $_POST['ucourse'];
    $phone = $_POST['uphone'];
    
    $sql = "UPDATE student SET name='$name', course='$course', phone='$phone' WHERE id=$user_id";

    $result = mysqli_query($conn, $sql);
}

?>
