<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <title>PHP Modal CRUD</title>
  </head>
  <body>
  <div class="container">
        <h2 class="text-center my-3">PHP Modal CRUD</h2>
        <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#studentModal">
  Add new student
        </button>
        <div id="displayDataTable"></div>
  </div>
  </body>
    <!-- Jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>

<!-- Scripts -->
<script>
// -----------------------------------------------------------------------
// display Table Student
$(document).ready(function() {
    displayData();
});

// -----------------------------------------------------------------------
// create Table Student
function displayData() {
    var displayData = "true";
    $.ajax({
        url: "display.php",
        type: "post",
        data: {
            displaySend:displayData
        },
        success: function(data,status) {
            $('#displayDataTable').html(data);
        }
    });
}

// -----------------------------------------------------------------------
// insert Student
function adduser() {
    var name=$('#name').val();
    var course=$('#course').val();
    var phone=$('#phone').val();

    $.ajax({
        url: "insert.php",
        type: "post",
        data: {
            nameSend: name,
            courseSend: course,
            phoneSend: phone
        },
        success: function(data, status) {
            $('#studentModal').modal('hide');
            displayData();
        }
    });
}

// -----------------------------------------------------------------------
// update student
function updateuser(updateid) {
    $('#hiddendata').val(updateid);

    $.post("update.php", {updateid:updateid}, function(data,status){
        var userid = JSON.parse(data);
        $('#uname').val(userid.name);
        $('#ucourse').val(userid.course);
        $('#uphone').val(userid.phone);
    });

    $('#updateStudentModal').modal("show");   
}

// -----------------------------------------------------------------------
function updatestudent() {
    var uname = $('#uname').val();
    var ucourse = $('#ucourse').val();
    var uphone = $('#uphone').val();
    var hiddendata = $('#hiddendata').val();

    $.post("update.php", {
        uname: uname,
        ucourse: ucourse,
        uphone: uphone,
        hiddendata: hiddendata
    }, function(data, status){
        $('#updateStudentModal').modal('hide');
        displayData();
    });
}

// -----------------------------------------------------------------------
// delete Student
function deleteuser(deleteid) {
    $.ajax({
        url: "delete.php",
        type: "post",
        data: {
            deleteSend: deleteid
        },
        success: function(data, status) {
            displayData();
        }
    });
}

</script>
</html>

<!-- Insert Modal -->
<div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add student</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="insert.php" method="post">
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" id="name">
            </div>
            <div class="form-group">
                <label>Course</label>
                <input type="text" class="form-control" id="course">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" class="form-control" id="phone">
            </div>
      <div class="modal-footer">
        <button type="button" onclick="adduser()" class="btn btn-dark">Save</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </form>
        </div>  
      </div>
    </div>
  </div>
</div>
<!-- Fim de Insert Modal -->

<!-- Update Modal -->
<div class="modal fade" id="updateStudentModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update student</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="update.php" method="post">
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" name="uname" id="uname">
            </div>
            <div class="form-group">
                <label>Course</label>
                <input type="text" class="form-control" name="ucourse" id="ucourse">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" class="form-control" name="uphone" id="uphone">
            </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" onclick="updatestudent()">Update</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="hidden" name="hiddendata" id="hiddendata">
        </form>
        </div>  
      </div>
    </div>
  </div>
</div>
<!-- Fim de Update Modal -->
