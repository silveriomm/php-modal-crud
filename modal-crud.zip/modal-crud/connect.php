<?php 

$conn = new mysqli('localhost', 'root', '', 'modal-crud');

if(!$conn)
{
    die(mysqli_error($conn));
}

?>
